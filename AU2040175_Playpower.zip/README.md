# Frontend

## How to install

```
npm install
```

## How to run

- Start the server code, it will start a local node server on port 8080

```
npm run server
```

then start react server on port 3000 in other terminal

```
npm run start
```
